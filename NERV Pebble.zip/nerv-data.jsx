/* ============================================================
   NERV live data layer
   Real time + battery (Battery API w/ fallback) + simulated
   steps/sync + weather. All values overridable for previewing.
   ============================================================ */
const { useState, useEffect, useRef } = React;

/* ---- live clock, ticks every second ---- */
function useClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    let id;
    const tick = () => setNow(new Date());
    // align to the next second
    const align = 1000 - (Date.now() % 1000);
    const t = setTimeout(() => { tick(); id = setInterval(tick, 1000); }, align);
    return () => { clearTimeout(t); clearInterval(id); };
  }, []);
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  const days = ["SUN","MON","TUE","WED","THU","FRI","SAT"];
  const mons = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
  return {
    now, hh, mm, ss,
    time24: `${hh}:${mm}`,
    day: days[now.getDay()],
    dd: String(now.getDate()).padStart(2, "0"),
    mon: mons[now.getMonth()],
    dateStr: `${days[now.getDay()]} ${String(now.getDate()).padStart(2,"0")} ${mons[now.getMonth()]}`,
  };
}

/* ---- battery: real if available, else stable fallback ---- */
function useBattery(fallback = 82) {
  const [bat, setBat] = useState({ level: fallback, charging: false, real: false });
  useEffect(() => {
    let mgr;
    const sync = () => setBat({
      level: Math.round(mgr.level * 100),
      charging: mgr.charging, real: true,
    });
    if (navigator.getBattery) {
      navigator.getBattery().then((m) => {
        mgr = m; sync();
        m.addEventListener("levelchange", sync);
        m.addEventListener("chargingchange", sync);
      }).catch(() => {});
    }
    return () => { if (mgr){ mgr.removeEventListener("levelchange", sync); mgr.removeEventListener("chargingchange", sync);} };
  }, []);
  return bat;
}

/* ---- activity: steps accumulate over the day; sync = % of goal ---- */
function useActivity(goal = 10000) {
  const { now } = useClock();
  // deterministic curve: most steps logged 7am-9pm
  const minutes = now.getHours() * 60 + now.getMinutes();
  const frac = Math.min(1, Math.max(0, (minutes - 360) / (21.5 * 60 - 360))); // 6:00 -> 21:30
  // gentle S-curve so it isn't linear
  const eased = frac * frac * (3 - 2 * frac);
  const steps = Math.round(eased * 8420 + (minutes % 7) * 11); // ~8.4k by evening
  const syncPct = Math.min(999, Math.round((steps / goal) * 100));
  return { steps, goal, syncPct };
}

/* ---- weather: stable demo values (swap for a real API later) ---- */
function useWeather() {
  // code maps to a short EVA-style label
  return { tempC: 18, hi: 21, lo: 12, code: "CLR", label: "CLEAR", icon: "☀" };
}

/* Merge live data with optional preview overrides (from Tweaks). */
function useNervData(ov = {}) {
  const clock = useClock();
  const bat = useBattery(ov.battery ?? 82);
  const act = useActivity(ov.stepGoal ?? 10000);
  const wx = useWeather();
  return {
    ...clock,
    battery: ov.battery ?? bat.level,
    charging: ov.charging ?? bat.charging,
    batteryReal: bat.real,
    steps: ov.steps ?? act.steps,
    stepGoal: ov.stepGoal ?? act.goal,
    syncPct: ov.steps != null ? Math.round((ov.steps / (ov.stepGoal ?? act.goal)) * 100) : act.syncPct,
    tempC: ov.tempC ?? wx.tempC,
    wxLabel: ov.wxLabel ?? wx.label,
    wxCode: ov.wxCode ?? wx.code,
    wxIcon: wx.icon,
    hi: wx.hi, lo: wx.lo,
  };
}

Object.assign(window, { useClock, useBattery, useActivity, useWeather, useNervData });
