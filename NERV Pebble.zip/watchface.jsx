/* ============================================================
   NERV · Pebble Time 2 — FINAL watchface (Layout B1)
   Centered in viewport, with a Tweaks panel.
   ============================================================ */
const L_LABELS = ["L-01","L-02","L-03","L-04","L-05","L-06","L-07"];

const FONT_THEMES = {
  "Chakra Petch":   { "--nerv-font-display": '"Chakra Petch",sans-serif',          "--nerv-font-ui": '"Chakra Petch",sans-serif' },
  "Saira":          { "--nerv-font-display": '"Saira","Saira Condensed",sans-serif',"--nerv-font-ui": '"Saira Condensed","Saira",sans-serif' },
  "Anton / Oswald": { "--nerv-font-display": '"Anton",sans-serif',                  "--nerv-font-ui": '"Oswald",sans-serif' },
  "Share Tech Mono":{ "--nerv-font-display": '"Share Tech Mono",monospace',         "--nerv-font-ui": '"Share Tech Mono",monospace' },
};
const FONT_CLOCK = { "Chakra Petch":60, "Saira":66, "Anton / Oswald":62, "Share Tech Mono":52 };

const powColor = (p) => (p <= 15 ? "var(--nerv-yellow)" : "var(--nerv-red)");

/* accent hex -> matching pre-tinted logo variant */
const LOGO_FOR_ACCENT = {
  "#ff2424": "assets/nerv-logo.png",
  "#ff7a18": "assets/nerv-logo-amber.png",
  "#ffd400": "assets/nerv-logo-amber.png",
  "#34e07a": "assets/nerv-logo-green.png",
  "#2fe6e6": "assets/nerv-logo-cyan.png",
};

/* ---- Pebble Time 2 bezel ---- */
function PebbleTime2({ children }) {
  return (
    <div className="pt2-body">
      <div className="pt2-btn left b2" />
      <div className="pt2-btn right b1" />
      <div className="pt2-btn right b2" />
      <div className="pt2-btn right b3" />
      <div className="pt2-screen-frame">
        <div className="pt2-screen-clip">
          <div className="pt2-screen">{children}</div>
        </div>
      </div>
    </div>
  );
}

/* ---- the B1 watchface screen ---- */
function WatchfaceB1({ d, timeStr, fonts, clockSize, crt, accent }) {
  const screenStyle = { ...fonts, "--nerv-red": accent };
  const logoSrc = LOGO_FOR_ACCENT[accent] || "assets/nerv-logo.png";
  return (
    <div className={`screen ${crt ? "crt" : ""}`} style={screenStyle}>
      {/* NERV logo — centered in the left half, tinted to match the accent */}
      <div style={{ position:"absolute", left:8, top:12, width:88, height:104, display:"grid", placeItems:"center" }}>
        <NervLogo src={logoSrc} style={{ width:"100%", height:"100%" }} />
      </div>
      {/* battery chevron meter, flush to the right border, centered on the logo */}
      <div style={{ position:"absolute", right:1, top:23, display:"flex", justifyContent:"flex-end", alignItems:"center", gap:2 }}>
        <ChevronStack battery={d.battery} count={7} width={54} chevH={10} gap={2}
          labels={L_LABELS} showTicks={true} ghost={true} pillSize={7} />
        <VScale max={100} step={20} height={82} fontSize={7} />
      </div>
      {/* zone label */}
      <div className="lbl" style={{ position:"absolute", left:9, top:120, fontSize:8, color:"#8c8c8c", whiteSpace:"nowrap" }}>LOCAL TIME // ACTIVE</div>
      {/* clock — centered horizontally + vertically between label and bottom row */}
      <div style={{ position:"absolute", left:0, right:0, top:132, bottom:36, display:"flex", alignItems:"center", justifyContent:"center" }}>
        <BigClock value={timeStr} size={clockSize} style={{ textAlign:"center" }} />
      </div>
      {/* bottom readouts: date · steps · weather */}
      <div style={{ position:"absolute", left:9, right:9, bottom:12, height:24, display:"flex", gap:5, alignItems:"stretch" }}>
        <Chip color="pink" style={{ flex:1.25, fontSize:9 }}>{d.day} {d.dd} {d.mon}</Chip>
        <Chip color="yellow" style={{ flex:1.25, flexDirection:"column", gap:0, lineHeight:1 }}>
          <span style={{ fontSize:6, opacity:.85 }}>STEPS</span>
          <span style={{ fontSize:12, fontWeight:800 }}>{d.steps.toLocaleString()}</span>
        </Chip>
        <Chip color="cyan" style={{ width:50, fontSize:12, fontWeight:800, gap:3 }}>
          <WeatherIcon code={d.wxCode} size={11} />
          <span>{d.tempC}°</span>
        </Chip>
      </div>
    </div>
  );
}

/* ============================================================
   APP
   ============================================================ */
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "typeface": "Chakra Petch",
  "format": "24h",
  "accent": "#ff2424",
  "liveBattery": true,
  "battery": 72,
  "weather": "CLR",
  "temp": 18,
  "crt": false
}/*EDITMODE-END*/;

const WEATHER_OPTS = ["CLR","CLOUDS","RAIN","SNOW"];

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  const ov = { wxCode: t.weather, tempC: t.temp };
  if (!t.liveBattery) ov.battery = t.battery;
  const d = useNervData(ov);

  // time string honoring 12/24h
  let timeStr = `${d.hh}:${d.mm}`;
  if (t.format === "12h") {
    const h12 = (d.now.getHours() % 12) || 12;
    timeStr = `${h12}:${d.mm}`;
  }

  const fonts = FONT_THEMES[t.typeface] || FONT_THEMES["Chakra Petch"];
  const clockSize = FONT_CLOCK[t.typeface] || 60;

  return (
    <div style={{ minHeight:"100vh", display:"grid", placeItems:"center", padding:24, boxSizing:"border-box" }}>
      <PebbleTime2>
        <WatchfaceB1 d={d} timeStr={timeStr} fonts={fonts} clockSize={clockSize}
          crt={t.crt} accent={t.accent} />
      </PebbleTime2>

      <TweaksPanel>
        <TweakSection label="Type & time" />
        <TweakSelect label="Typeface" value={t.typeface}
          options={Object.keys(FONT_THEMES)} onChange={(v)=>setTweak("typeface", v)} />
        <TweakRadio label="Clock" value={t.format} options={["24h","12h"]}
          onChange={(v)=>setTweak("format", v)} />

        <TweakSection label="Color" />
        <TweakColor label="Accent" value={t.accent}
          options={["#ff2424","#ff7a18","#ffd400","#34e07a","#2fe6e6"]}
          onChange={(v)=>setTweak("accent", v)} />
        <TweakToggle label="CRT scanlines" value={t.crt} onChange={(v)=>setTweak("crt", v)} />

        <TweakSection label="Battery" />
        <TweakToggle label="Use device battery" value={t.liveBattery}
          onChange={(v)=>setTweak("liveBattery", v)} />
        {!t.liveBattery && (
          <TweakSlider label="Battery preview" value={t.battery} min={0} max={100} unit="%"
            onChange={(v)=>setTweak("battery", v)} />
        )}

        <TweakSection label="Weather (demo)" />
        <TweakSelect label="Condition" value={t.weather} options={WEATHER_OPTS}
          onChange={(v)=>setTweak("weather", v)} />
        <TweakSlider label="Temp" value={t.temp} min={-10} max={45} unit="°C"
          onChange={(v)=>setTweak("temp", v)} />
      </TweaksPanel>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
