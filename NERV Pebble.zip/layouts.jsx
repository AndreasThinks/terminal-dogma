/* ============================================================
   NERV — Pebble Time 2 watchface layout explorations
   Native screen space: 200 x 228
   ============================================================ */

const L_LABELS = ["L-01","L-02","L-03","L-04","L-05","L-06","L-07"];

/* ---- bezel + screen shells ---- */
function PebbleTime2({ children }) {
  return (
    <div className="pt2-body">
      <div className="pt2-btn left b2" />
      <div className="pt2-btn right b1" />
      <div className="pt2-btn right b2" />
      <div className="pt2-btn right b3" />
      <div className="pt2-screen-frame">
        <div className="pt2-screen-clip">
          <div className="pt2-screen">{children}</div>
        </div>
      </div>
    </div>
  );
}
function Screen({ children, crt, style }) {
  return <div className={`screen ${crt ? "crt" : ""}`} style={style}>{children}</div>;
}

/* NERV-style font themes (set CSS vars on the screen) */
const FONT_THEMES = {
  base:     { "--nerv-font-display": '"Saira","Saira Condensed",sans-serif', "--nerv-font-ui": '"Saira Condensed","Saira",sans-serif' },
  chakra:   { "--nerv-font-display": '"Chakra Petch",sans-serif',            "--nerv-font-ui": '"Chakra Petch",sans-serif' },
  anton:    { "--nerv-font-display": '"Anton",sans-serif',                   "--nerv-font-ui": '"Oswald",sans-serif' },
  techmono: { "--nerv-font-display": '"Share Tech Mono",monospace',          "--nerv-font-ui": '"Share Tech Mono",monospace' },
};

/* small EVA pct color helper */
const powColor = (p) => (p <= 15 ? "var(--nerv-yellow)" : "var(--nerv-red)");

/* ============================================================
   A — CENTRAL DOGMA  (faithful adaptation of reference #1)
   ============================================================ */
function LayoutA({ d, crt }) {
  return (
    <Screen crt={crt}>
      <HazardFrame />
      {/* logo */}
      <div style={{ position:"absolute", left:8, top:12, width:66, height:60 }}>
        <NervLogo />
      </div>
      {/* battery cluster, top-right */}
      <div style={{ position:"absolute", right:8, top:8, width:110 }}>
        <div style={{ textAlign:"right", paddingRight:22 }}>
          <div className="lbl red" style={{ fontSize:9 }}>BATTERY</div>
          <div className="mono" style={{ fontSize:21, fontWeight:800, lineHeight:1, color:powColor(d.battery) }}>{d.battery}%</div>
        </div>
        <div style={{ display:"flex", justifyContent:"flex-end", gap:7, marginTop:5 }}>
          <ChevronStack battery={d.battery} count={7} width={50} chevH={11} gap={2} />
          <VScale max={100} step={20} height={92} fontSize={7} />
        </div>
      </div>
      {/* mid: clock */}
      <div style={{ position:"absolute", left:0, right:0, top:120 }}>
        <div className="lbl" style={{ fontSize:8, color:"#8c8c8c", paddingLeft:12 }}>ACTIVE TIME // LOCAL</div>
        <BigClock value={d.time24} size={62} style={{ textAlign:"center", marginTop:1 }} />
      </div>
      {/* bottom chips */}
      <div style={{ position:"absolute", left:8, right:8, bottom:13, height:32, display:"flex", gap:5, alignItems:"stretch" }}>
        <StripeBar color="cyan" style={{ width:9 }} />
        <Chip color="pink" style={{ flex:1.5, fontSize:11 }}>{d.day} {d.dd} {d.mon}</Chip>
        <ChipInternal style={{ flex:1.25, fontSize:11 }}>SYNC {d.syncPct}%</ChipInternal>
        <Chip color="cyan" style={{ width:34, fontSize:14, fontWeight:800 }}>{d.tempC}°</Chip>
      </div>
    </Screen>
  );
}

/* ============================================================
   B — L-SERIES  (labeled chevron stack hero, reference #2)
   ============================================================ */
function LayoutB({ d, crt, fonts, clockSize = 66 }) {
  return (
    <Screen crt={crt} style={fonts}>
      {/* NERV logo — centered in the left half */}
      <div style={{ position:"absolute", left:8, top:12, width:88, height:104, display:"grid", placeItems:"center" }}>
        <NervLogo />
      </div>
      {/* battery meter — hugs the right border, vertically centered on the logo */}
      <div style={{ position:"absolute", right:1, top:23, display:"flex", justifyContent:"flex-end", alignItems:"center", gap:2 }}>
        <ChevronStack battery={d.battery} count={7} width={54} chevH={10} gap={2}
          labels={L_LABELS} showTicks={true} ghost={true} pillSize={7} />
        <VScale max={100} step={20} height={82} fontSize={7} />
      </div>
      {/* lower zone label */}
      <div className="lbl" style={{ position:"absolute", left:9, top:120, fontSize:8, color:"#8c8c8c", whiteSpace:"nowrap" }}>LOCAL TIME // ACTIVE</div>
      {/* clock: centered horizontally + vertically between label and bottom row */}
      <div style={{ position:"absolute", left:0, right:0, top:132, bottom:36,
        display:"flex", alignItems:"center", justifyContent:"center" }}>
        <BigClock value={d.time24} size={clockSize} style={{ textAlign:"center" }} />
      </div>
      {/* bottom readouts: date · steps · weather */}
      <div style={{ position:"absolute", left:9, right:9, bottom:12, height:24, display:"flex", gap:5, alignItems:"stretch" }}>
        <Chip color="pink" style={{ flex:1.25, fontSize:9 }}>{d.day} {d.dd} {d.mon}</Chip>
        <Chip color="yellow" style={{ flex:1.25, flexDirection:"column", gap:0, lineHeight:1 }}>
          <span style={{ fontSize:6, opacity:.85 }}>STEPS</span>
          <span style={{ fontSize:12, fontWeight:800 }}>{d.steps.toLocaleString()}</span>
        </Chip>
        <Chip color="cyan" style={{ width:50, fontSize:12, fontWeight:800, gap:3 }}>
          <WeatherIcon code={d.wxCode} size={11} />
          <span>{d.tempC}°</span>
        </Chip>
      </div>
    </Screen>
  );
}

/* ============================================================
   C — MAGI TERMINAL  (novel data-console, horizontal gauges)
   ============================================================ */
function GaugeRow({ label, pct, value, top, low }) {
  const col = low ? "var(--nerv-yellow)" : "var(--nerv-red)";
  return (
    <div style={{ position:"absolute", left:8, right:8, top, display:"flex", alignItems:"center", gap:6 }}>
      <div className="lbl" style={{ fontSize:8, color:"#cfcfcf", width:54 }}>{label}</div>
      <div style={{ flex:1 }}>
        <SegBar pct={pct} segs={14} height={9} yellow={low} />
      </div>
      <div className="mono" style={{ fontSize:12, fontWeight:800, width:36, textAlign:"right", color:col }}>{value}</div>
    </div>
  );
}
function LayoutC({ d, crt }) {
  return (
    <Screen crt={crt}>
      <HazardFrame />
      {/* header */}
      <div style={{ position:"absolute", left:8, top:9, display:"flex", alignItems:"center", gap:7 }}>
        <div style={{ width:32, height:34 }}><NervLogo /></div>
        <div>
          <div className="lbl red" style={{ fontSize:10, whiteSpace:"nowrap" }}>MAGI SYSTEM</div>
          <div className="lbl" style={{ fontSize:6.5, color:"#8c8c8c", whiteSpace:"nowrap", letterSpacing:".04em" }}>CASPER·MELCHIOR·BALTHASAR</div>
        </div>
      </div>
      {/* date top-right */}
      <div style={{ position:"absolute", right:38, top:10, textAlign:"right" }}>
        <div className="mono" style={{ fontSize:12, fontWeight:800, color:"#fff", whiteSpace:"nowrap", lineHeight:1 }}>{d.dd} {d.mon}</div>
        <div className="lbl red" style={{ fontSize:8, marginTop:1 }}>{d.day}</div>
      </div>
      <div className="rule red" style={{ left:8, right:8, top:46 }} />
      {/* time */}
      <div style={{ position:"absolute", left:8, right:8, top:52 }}>
        <div className="lbl" style={{ fontSize:8, color:"#8c8c8c" }}>LOCAL TIME // ACTIVE</div>
        <BigClock value={d.time24} size={58} style={{ textAlign:"center", marginTop:1 }} />
      </div>
      <div className="rule" style={{ left:8, right:8, top:126, background:"#2a2a2a" }} />
      {/* gauges */}
      <GaugeRow label="POWER" pct={d.battery} value={`${d.battery}%`} top={136} low={d.battery <= 15} />
      <GaugeRow label="SYNC"  pct={d.syncPct} value={`${d.syncPct}%`} top={164} />
      {/* footer: steps + atmospheric */}
      <div style={{ position:"absolute", left:8, right:8, bottom:13, display:"flex", justifyContent:"space-between", alignItems:"flex-end" }}>
        <Readout k="STEPS" v={d.steps.toLocaleString()} vSize={15} color="#fff" />
        <Readout k="ATMOSPHERIC" v={`${d.tempC}° ${d.wxLabel}`} vSize={13} color="var(--nerv-cyan)" align="right" />
      </div>
    </Screen>
  );
}

/* ============================================================
   D — PATTERN ORANGE  (minimal, battery-friendly, clock-hero)
   ============================================================ */
function LayoutD({ d, crt }) {
  return (
    <Screen crt={crt}>
      <HazardFrame corners={["tl","br"]} />
      {/* logo */}
      <div style={{ position:"absolute", left:10, top:12, width:46, height:40 }}>
        <NervLogo />
      </div>
      {/* date top-right */}
      <div style={{ position:"absolute", right:28, top:13, textAlign:"right" }}>
        <div className="mono" style={{ fontSize:15, fontWeight:800, color:"#fff", lineHeight:1, whiteSpace:"nowrap" }}>{d.day} {d.dd}</div>
        <div className="lbl red" style={{ fontSize:9, marginTop:2 }}>{d.mon}</div>
      </div>
      {/* thin chevron battery strip, right edge */}
      <div style={{ position:"absolute", right:9, top:70 }}>
        <div className="lbl red" style={{ fontSize:7, textAlign:"center", marginBottom:3 }}>{d.battery}</div>
        <ChevronStack battery={d.battery} count={7} width={13} chevH={10} gap={2} showTicks={false} />
      </div>
      {/* huge clock */}
      <div style={{ position:"absolute", left:2, right:30, top:104 }}>
        <BigClock value={d.time24} size={60} style={{ textAlign:"center" }} />
      </div>
      {/* bottom line */}
      <div style={{ position:"absolute", left:10, right:10, bottom:16, display:"flex", justifyContent:"space-between", alignItems:"center" }}>
        <Readout k="SYNC RATIO" v={`${d.syncPct}%`} vSize={15} color="var(--nerv-yellow)" />
        <div className="lbl" style={{ fontSize:9, color:"#8c8c8c" }}>{d.steps.toLocaleString()} STEPS</div>
        <Readout k="ATMOS" v={`${d.tempC}°`} vSize={15} color="var(--nerv-cyan)" align="right" />
      </div>
    </Screen>
  );
}

/* ============================================================
   APP — design canvas of the four options
   ============================================================ */
function NervApp() {
  const d = useNervData();
  const frame = (Comp) => (
    <PebbleTime2><Comp d={d} /></PebbleTime2>
  );
  const frameB = (fonts, clockSize) => (
    <PebbleTime2><LayoutB d={d} fonts={fonts} clockSize={clockSize} /></PebbleTime2>
  );
  return (
    <DesignCanvas>
      <DCSection id="faithful" title="Faithful adaptations"
        subtitle="Your two reference layouts, re-flowed for the Time 2's 200×228 portrait screen.">
        <DCArtboard id="A" label="A · CENTRAL DOGMA — battery gauge" width={512} height={508}>
          <div style={{display:"grid", placeItems:"center", height:"100%"}}>{frame(LayoutA)}</div>
        </DCArtboard>
        <DCArtboard id="B" label="B · L-SERIES — Saira (current)" width={512} height={508}>
          <div style={{display:"grid", placeItems:"center", height:"100%"}}>{frame(LayoutB)}</div>
        </DCArtboard>
      </DCSection>
      <DCSection id="type" title="B · Type studies"
        subtitle="Layout B with three NERV-flavoured typefaces. Same data, different voice.">
        <DCArtboard id="B-chakra" label="B1 · CHAKRA PETCH — squared HUD" width={512} height={508}>
          <div style={{display:"grid", placeItems:"center", height:"100%"}}>{frameB(FONT_THEMES.chakra, 60)}</div>
        </DCArtboard>
        <DCArtboard id="B-anton" label="B2 · ANTON / OSWALD — propaganda" width={512} height={508}>
          <div style={{display:"grid", placeItems:"center", height:"100%"}}>{frameB(FONT_THEMES.anton, 60)}</div>
        </DCArtboard>
        <DCArtboard id="B-mono" label="B3 · SHARE TECH MONO — terminal" width={512} height={508}>
          <div style={{display:"grid", placeItems:"center", height:"100%"}}>{frameB(FONT_THEMES.techmono, 52)}</div>
        </DCArtboard>
      </DCSection>
      <DCSection id="novel" title="New directions"
        subtitle="Same NERV DNA, rethought for legibility and density on the wrist.">
        <DCArtboard id="C" label="C · MAGI TERMINAL — data console" width={512} height={508}>
          <div style={{display:"grid", placeItems:"center", height:"100%"}}>{frame(LayoutC)}</div>
        </DCArtboard>
        <DCArtboard id="D" label="D · PATTERN ORANGE — minimal" width={512} height={508}>
          <div style={{display:"grid", placeItems:"center", height:"100%"}}>{frame(LayoutD)}</div>
        </DCArtboard>
      </DCSection>
    </DesignCanvas>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<NervApp />);
