/* ============================================================
   NERV reusable HUD parts (React)
   ============================================================ */

/* ---- Hazard corner frame ---- */
function HazardFrame({ corners = ["tl","tr","bl","br"] }) {
  return (
    <div className="haz-frame">
      {corners.map((c) => (
        <div key={c} className={`haz-corner ${c}`}>
          <div className="h haz-stripes" />
          <div className="v haz-stripes" />
        </div>
      ))}
    </div>
  );
}

/* ---- NERV logo image ---- */
/* ---- NERV logo image (src can point at a pre-tinted variant) ---- */
function NervLogo({ style, src = "assets/nerv-logo.png" }) {
  return <img className="nerv-logo" src={src} alt="NERV" style={style} draggable={false} />;
}

/* ---- Vertical chevron battery stack ----
   battery 0..100, count segments. Lights from bottom up. */
function ChevronStack({ battery = 82, count = 7, width = 78, chevH = 13, gap = 2,
                        labels = null, showTicks = true, pillSize = 8, ghost = false }) {
  const lit = Math.round((battery / 100) * count);
  const rows = [];
  for (let i = 0; i < count; i++) {
    const on = (count - i) <= lit;       // bottom segments fill first
    const topMost = i === (count - lit); // first lit from top
    rows.push(
      <div key={i} className={`chev-row ${on ? "" : "off-pill"} ${ghost ? "ghost" : ""}`} style={{ height: chevH }}>
        <div className={`chev ${on ? "" : "off"}`}>
          {showTicks && <span className="tick" />}
          {topMost && battery < 100 && (
            <span style={{ position:"absolute", right:"7%", top:"8%", width:"20%", height:"40%",
              background:"var(--nerv-yellow)",
              clipPath:"polygon(100% 0, 100% 100%, 0 0)" }} />
          )}
        </div>
        {labels && <span className="chev-pill" style={{ fontSize: pillSize }}>{labels[i]}</span>}
      </div>
    );
  }
  return <div className="chev-stack" style={{ width }}>{rows}</div>;
}

/* ---- Vertical scale 0..max ---- */
function VScale({ max = 100, step = 20, height = 150, fontSize = 9, bracket = false }) {
  const majors = [];
  for (let v = 0; v <= max; v += step) majors.push(v);
  const minors = [];
  for (let v = 0; v <= max; v += step / 2) if (v % step !== 0) minors.push(v);
  const yOf = (v) => height - (v / max) * height;
  return (
    <div className="vscale" style={{ height, width: 22 }}>
      <div className="spine" />
      {bracket && <div className="tick major" style={{ top: -0, right: 0, width: 12, height: 2 }} />}
      {majors.map((v) => (
        <React.Fragment key={"M"+v}>
          <div className="tick major" style={{ top: yOf(v) }} />
          <div className="num" style={{ top: yOf(v), fontSize }}>{v}</div>
        </React.Fragment>
      ))}
      {minors.map((v) => (
        <div key={"m"+v} className="tick minor" style={{ top: yOf(v) }} />
      ))}
    </div>
  );
}

/* ---- Status chip (outline label) ---- */
function Chip({ color = "pink", children, style }) {
  return <div className={`chip ${color}`} style={style}>{children}</div>;
}

/* ---- "INTERNAL"-style yellow chip with red hazard cap ---- */
function ChipInternal({ children, style }) {
  return (
    <div className="chip-internal" style={style}>
      <span style={{ flex: 1, textAlign: "center", paddingRight: "18%" }}>{children}</span>
      <span className="cap" />
    </div>
  );
}

/* ---- striped accent bar ---- */
function StripeBar({ color = "cyan", style }) {
  return <div className={`stripe-bar ${color}`} style={style} />;
}

/* ---- big tabular clock ---- */
function BigClock({ value = "20:35", size = 64, blink = true, style }) {
  const [h, m] = value.split(":");
  return (
    <div className="bigclock" style={{ fontSize: size, ...style }}>
      {h}<span className={`colon ${blink ? "blink" : ""}`}>:</span>{m}
    </div>
  );
}

/* ---- compact label/value readout ---- */
function Readout({ k, v, color = "var(--nerv-white)", kSize = 8, vSize = 15, align = "left", style }) {
  return (
    <div className="readout" style={{ textAlign: align, ...style }}>
      <div className="k" style={{ fontSize: kSize, color: "#8c8c8c" }}>{k}</div>
      <div className="v" style={{ fontSize: vSize, color }}>{v}</div>
    </div>
  );
}

/* ---- segmented horizontal bar (sync ratio etc.) ---- */
function SegBar({ pct = 60, segs = 12, height = 8, yellow = false, style }) {
  const on = Math.round((Math.min(100, pct) / 100) * segs);
  return (
    <div className="segbar" style={{ height, ...style }}>
      {Array.from({ length: segs }).map((_, i) => (
        <div key={i} className={`s ${i < on ? "on" : ""} ${yellow ? "warn" : ""}`} />
      ))}
    </div>
  );
}

/* ---- weather icon (simple CSS shapes; inherits color) ---- */
function WeatherIcon({ code = "CLR", size = 12, style }) {
  const box = { position:"relative", width: size*1.35, height: size, display:"inline-block", color:"currentColor", flex:"0 0 auto", ...style };
  const C = code.toUpperCase();
  // sun
  if (C === "CLR" || C === "CLEAR" || C === "SUN") {
    const disc = size*0.56;
    return (
      <span style={box}>
        {Array.from({ length: 8 }).map((_, i) => (
          <span key={i} style={{ position:"absolute", left:"50%", top:"50%", width:1.4, height:size*0.16,
            background:"currentColor", borderRadius:1,
            transform:`translate(-50%,-50%) rotate(${i*45}deg) translateY(-${size*0.44}px)` }} />
        ))}
        <span style={{ position:"absolute", left:"50%", top:"50%", width:disc, height:disc, borderRadius:"50%",
          background:"currentColor", transform:"translate(-50%,-50%)" }} />
      </span>
    );
  }
  const cloud = (
    <>
      <span style={{ position:"absolute", left:"10%", bottom:"16%", width:"80%", height:"40%", borderRadius:99, background:"currentColor" }} />
      <span style={{ position:"absolute", left:"16%", top:"20%", width:"44%", height:"54%", borderRadius:"50%", background:"currentColor" }} />
      <span style={{ position:"absolute", left:"42%", top:"8%", width:"48%", height:"62%", borderRadius:"50%", background:"currentColor" }} />
    </>
  );
  if (C === "RAIN" || C === "SHOWERS") {
    return (
      <span style={box}>
        {cloud}
        {[0,1,2].map((i) => (
          <span key={i} style={{ position:"absolute", bottom:-1, left:`${24+i*24}%`, width:1.4, height:size*0.26,
            background:"currentColor", borderRadius:1, transform:"rotate(16deg)" }} />
        ))}
      </span>
    );
  }
  if (C === "SNOW") {
    return (
      <span style={box}>
        {cloud}
        {[0,1,2].map((i) => (
          <span key={i} style={{ position:"absolute", bottom:0, left:`${26+i*24}%`, width:size*0.13, height:size*0.13,
            background:"currentColor", borderRadius:"50%" }} />
        ))}
      </span>
    );
  }
  // clouds (default)
  return <span style={box}>{cloud}</span>;
}

Object.assign(window, { HazardFrame, NervLogo, ChevronStack, VScale, Chip, ChipInternal, StripeBar, BigClock, Readout, SegBar, WeatherIcon });
